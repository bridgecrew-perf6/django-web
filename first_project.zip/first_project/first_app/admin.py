from django.contrib import admin
from first_app.models import HotelChain,Hotel

admin.site.register(Hotel)
admin.site.register(HotelChain)

# Register your models here.
